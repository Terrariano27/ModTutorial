using Terraria.ModLoader;

namespace ModTutorial
{
	public class ModTutorial : Mod
	{
	}
}